
# Create Deal Request

*This model accepts additional fields of type Any.*

## Structure

`CreateDealRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `scenario_id` | `str` | Required | - |
| `buyer_max` | float \| None | Optional | This is a container for any-of cases. |
| `seller_floor` | float \| None | Optional | This is a container for any-of cases. |
| `bond_percent` | float \| None | Optional | This is a container for any-of cases. |
| `multi_issue` | `bool` | Optional | **Default**: `False` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from pact.models.create_deal_request import CreateDealRequest

create_deal_request = CreateDealRequest(
    scenario_id='scenario_id2',
    buyer_max=106.4,
    seller_floor=77.84,
    bond_percent=245.26,
    multi_issue=False,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

