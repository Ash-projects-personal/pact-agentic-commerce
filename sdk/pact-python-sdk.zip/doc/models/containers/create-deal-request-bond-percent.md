
# Create Deal Request Bond Percent

## Data Type

`float`

## Cases

| Type |
|  --- |
| `float` |

## float

### Initialization Code

#### Example

```python
value = 0
```

