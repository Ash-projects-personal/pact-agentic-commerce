
# Create Deal Request Seller Floor

## Data Type

`float`

## Cases

| Type |
|  --- |
| `float` |

## float

### Initialization Code

#### Example

```python
value = 0
```

