
# Create Deal Request Buyer Max

## Data Type

`float`

## Cases

| Type |
|  --- |
| `float` |

## float

### Initialization Code

#### Example

```python
value = 0
```

