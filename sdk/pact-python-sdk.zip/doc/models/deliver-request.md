
# Deliver Request

*This model accepts additional fields of type Any.*

## Structure

`DeliverRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `quality` | `str` | Optional | **Default**: `"auto"` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from pact.models.deliver_request import DeliverRequest

deliver_request = DeliverRequest(
    quality='auto',
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

