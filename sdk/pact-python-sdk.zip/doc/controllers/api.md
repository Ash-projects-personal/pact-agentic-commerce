# API

```python
client_api = client.client
```

## Class Name

`Api`

## Methods

* [Index Get](../../doc/controllers/api.md#index-get)
* [Health Api Health Get](../../doc/controllers/api.md#health-api-health-get)
* [Ready Api Ready Get](../../doc/controllers/api.md#ready-api-ready-get)
* [Scenarios Api Scenarios Get](../../doc/controllers/api.md#scenarios-api-scenarios-get)
* [Agents Api Agents Get](../../doc/controllers/api.md#agents-api-agents-get)
* [Create Deal Api Deals Post](../../doc/controllers/api.md#create-deal-api-deals-post)
* [Get Deal Api Deals Deal Id Get](../../doc/controllers/api.md#get-deal-api-deals-deal-id-get)
* [Dispute Packet Api Deals Deal Id Dispute Packet Get](../../doc/controllers/api.md#dispute-packet-api-deals-deal-id-dispute-packet-get)
* [Negotiate Api Deals Deal Id Negotiate Run Post](../../doc/controllers/api.md#negotiate-api-deals-deal-id-negotiate-run-post)
* [Pay Api Deals Deal Id Pay Post](../../doc/controllers/api.md#pay-api-deals-deal-id-pay-post)
* [Pay Confirm Api Deals Deal Id Pay Confirm Post](../../doc/controllers/api.md#pay-confirm-api-deals-deal-id-pay-confirm-post)
* [Deliver Api Deals Deal Id Deliver Post](../../doc/controllers/api.md#deliver-api-deals-deal-id-deliver-post)
* [Verify Api Deals Deal Id Verify Post](../../doc/controllers/api.md#verify-api-deals-deal-id-verify-post)
* [Paypal Webhook Webhooks Paypal Post](../../doc/controllers/api.md#paypal-webhook-webhooks-paypal-post)
* [Webhook Log Api Webhooks Get](../../doc/controllers/api.md#webhook-log-api-webhooks-get)


# Index Get

Serves the Pact demo UI.

```python
def index_get(self)
```

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
result = client_api.index_get()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```


# Health Api Health Get

Liveness probe. Reports the process is up, the mode (demo or PayPal sandbox), and the payment rails in use.

```python
def health_api_health_get(self)
```

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
result = client_api.health_api_health_get()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```


# Ready Api Ready Get

Readiness probe, separate from health. Returns 200 only when the startup config validates and the database passes a write/read probe. Deploys gate on this endpoint.

```python
def ready_api_ready_get(self)
```

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
result = client_api.ready_api_ready_get()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```


# Scenarios Api Scenarios Get

Lists the 14 deal scenarios with their candidate acceptance checks, price bounds, and seller agents.

```python
def scenarios_api_scenarios_get(self)
```

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
result = client_api.scenarios_api_scenarios_get()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```


# Agents Api Agents Get

Lists the buyer and seller agents with their reputation scores and deal counts.

```python
def agents_api_agents_get(self)
```

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
result = client_api.agents_api_agents_get()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```


# Create Deal Api Deals Post

Creates a deal from a scenario: sets the price bounds and bond percent, then the buyer and seller agents negotiate and freeze the contract. Procurement deals ground the bounds in live Channel3 market data first.

```python
def create_deal_api_deals_post(self,
                              body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`CreateDealRequest`](../../doc/models/create-deal-request.md) | Body, Required | - |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
body = CreateDealRequest(
    scenario_id='scenario_id6',
    multi_issue=False
)

result = client_api.create_deal_api_deals_post(body)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 422 | Validation Error | [`HttpValidationErrorException`](../../doc/models/http-validation-error-exception.md) |


# Get Deal Api Deals Deal Id Get

Returns one deal: state, frozen spec with the SHA-256 contract hash, money legs, ledger events, and settlement progress.

```python
def get_deal_api_deals_deal_id_get(self,
                                  deal_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deal_id` | `str` | Template, Required | - |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
deal_id = 'deal_id0'

result = client_api.get_deal_api_deals_deal_id_get(deal_id)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 422 | Validation Error | [`HttpValidationErrorException`](../../doc/models/http-validation-error-exception.md) |


# Dispute Packet Api Deals Deal Id Dispute Packet Get

Downloads the self-contained Markdown evidence file for one deal: transcript, frozen spec, check verdicts, reputation moves, and every PayPal transaction id.

```python
def dispute_packet_api_deals_deal_id_dispute_packet_get(self,
                                                       deal_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deal_id` | `str` | Template, Required | - |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
deal_id = 'deal_id0'

result = client_api.dispute_packet_api_deals_deal_id_dispute_packet_get(deal_id)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 422 | Validation Error | [`HttpValidationErrorException`](../../doc/models/http-validation-error-exception.md) |


# Negotiate Api Deals Deal Id Negotiate Run Post

Runs the negotiation for a created deal: the price phase first, then the multi-issue terms phase when the deal was created with multi_issue set.

```python
def negotiate_api_deals_deal_id_negotiate_run_post(self,
                                                  deal_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deal_id` | `str` | Template, Required | - |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
deal_id = 'deal_id0'

result = client_api.negotiate_api_deals_deal_id_negotiate_run_post(deal_id)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 422 | Validation Error | [`HttpValidationErrorException`](../../doc/models/http-validation-error-exception.md) |


# Pay Api Deals Deal Id Pay Post

Creates the price order and the bond order and returns the approval links. In demo mode the orders are simulated; in live mode the buyer and seller approve on PayPal.

```python
def pay_api_deals_deal_id_pay_post(self,
                                  deal_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deal_id` | `str` | Template, Required | - |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
deal_id = 'deal_id0'

result = client_api.pay_api_deals_deal_id_pay_post(deal_id)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 422 | Validation Error | [`HttpValidationErrorException`](../../doc/models/http-validation-error-exception.md) |


# Pay Confirm Api Deals Deal Id Pay Confirm Post

Confirms both PayPal orders are approved by the expected sandbox buyer and seller identities, then captures. Refuses capture with a ledger event when a payer does not match. Demo mode skips the check.

```python
def pay_confirm_api_deals_deal_id_pay_confirm_post(self,
                                                  deal_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deal_id` | `str` | Template, Required | - |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
deal_id = 'deal_id0'

result = client_api.pay_confirm_api_deals_deal_id_pay_confirm_post(deal_id)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 422 | Validation Error | [`HttpValidationErrorException`](../../doc/models/http-validation-error-exception.md) |


# Deliver Api Deals Deal Id Deliver Post

Submits the seller delivery text against the frozen contract. A weak delivery spends one revision round instead of settling.

```python
def deliver_api_deals_deal_id_deliver_post(self,
                                          deal_id,
                                          body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deal_id` | `str` | Template, Required | - |
| `body` | [`DeliverRequest`](../../doc/models/deliver-request.md) | Body, Optional | - |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
deal_id = 'deal_id0'

body = DeliverRequest(
    quality='auto'
)

result = client_api.deliver_api_deals_deal_id_deliver_post(
    deal_id,
    body=body
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 422 | Validation Error | [`HttpValidationErrorException`](../../doc/models/http-validation-error-exception.md) |


# Verify Api Deals Deal Id Verify Post

Runs the deterministic verifier over the delivery and settles the deal: release payout or refund plus bond slash, recorded leg by leg and resumable after a failure.

```python
def verify_api_deals_deal_id_verify_post(self,
                                        deal_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deal_id` | `str` | Template, Required | - |

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
deal_id = 'deal_id0'

result = client_api.verify_api_deals_deal_id_verify_post(deal_id)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 422 | Validation Error | [`HttpValidationErrorException`](../../doc/models/http-validation-error-exception.md) |


# Paypal Webhook Webhooks Paypal Post

Receives PayPal webhook events. Verifies the event signature when a webhook id is configured; events without one are recorded as unverified. Settlement never depends on webhooks.

```python
def paypal_webhook_webhooks_paypal_post(self)
```

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
result = client_api.paypal_webhook_webhooks_paypal_post()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```


# Webhook Log Api Webhooks Get

Lists the PayPal webhook events received so far, with their verification status.

```python
def webhook_log_api_webhooks_get(self)
```

## Response Type

**200**: Successful Response

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type `Any`.

## Example Usage

```python
result = client_api.webhook_log_api_webhooks_get()

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

